package com.cg.bs.exception;

public class NoRecordFoundException extends Exception {
	public String toString() {
  	  
  	  return "Incorrect Credentials";
    }
}
