package com.cg.bs.service;
import com.cg.bs.dao.IBookDao;
import com.cg.bs.exception.BookException;
import com.cg.bs.dao.BookDaoImpl;

import java.util.regex.Pattern;

import com.cg.bs.bean.BookBean;

public class BookServiceImpl implements IBookService
{
	IBookDao bookDao;
	public boolean validateUser(BookBean bookBean)
	{
		
		bookDao = new BookDaoImpl();
		return bookDao.validateUser(bookBean);
	}
	@Override
	public void listBook()
	{
		
		bookDao = new BookDaoImpl();
		bookDao.listBook();
	}
	@Override
	public void createBook(BookBean bookBean) {
		// TODO Auto-generated method stub
		String id;
		bookDao = new BookDaoImpl();
		bookDao.createBook(bookBean);
		//return id;
	}
	@Override
	public boolean deleteBook(String id1) throws BookException 
	{
		// TODO Auto-generated method stub
		bookDao = new BookDaoImpl();
		return bookDao.deleteBook(id1);
		//return false;
	}
	@Override
	public void editBook(String id2,BookBean bookBean) {
		// TODO Auto-generated method stub
		bookDao = new BookDaoImpl();
		bookDao.editBook(id2,bookBean);
	}
	
	
	public void validateName(String categoryName) throws BookException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{2,29}";
		if (!Pattern.matches(nameRegEx, categoryName)) {
			throw new BookException("first letter should be capital and length must be in between 3 to 30... \n");
		}
	}
	@Override
	public void validateDate(String publishDate) throws BookException {
		// TODO Auto-generated method stub
		String nameRegEx ="^\\d\\d\\d\\d-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01]) (00|[0-9]|1[0-9]|2[0-3]):([0-9]|[0-5][0-9]):([0-9]|[0-5][0-9])$";
		if (!Pattern.matches(nameRegEx, publishDate)) {
			throw new BookException("Enter the publish date correctly...\n");
		}
		
	}
	@Override
	public void validateIsbn(Long isbnNum) throws BookException {
		// TODO Auto-generated method stub
		String nameRegEx = "^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][0-9]{10}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)(?:97[89][- ]?)?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$";
		if (!Pattern.matches(nameRegEx, isbnNum.toString())) {
			throw new BookException("ISBN number should be 10 or 13 digits with correct format...\n");
		}
	}
	@Override
	public void validatePrice(Double price) throws BookException {
		// TODO Auto-generated method stub
		if (price < 100 || price > 50000) {
			throw new BookException("Price should not be less than 100 and should not exceed 50000... \n");
		}
	}
	@Override
	public void validateDescript(String descript) throws BookException {
		// TODO Auto-generated method stub
		//String nameRegEx = "[a-zA-Z0-9 ]{4,49}";
		if (descript.length()<5) {
			throw new BookException("Description shoud be greater than 5 characters and should not exceed 300 characters... \n");
	}
	}
}
	
	


