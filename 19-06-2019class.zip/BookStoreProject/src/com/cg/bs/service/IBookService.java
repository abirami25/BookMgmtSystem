package com.cg.bs.service;

import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;

public interface IBookService 
{
	public boolean validateUser(BookBean bookBean); 
	public void listBook();
	public void createBook(BookBean bookBean);
	public boolean deleteBook(String id1) throws BookException;
	public void editBook(String id2,BookBean bookBean);
	public void validateName(String categoryName) throws BookException;
	public void validateDate(String publishDate) throws BookException;
	public void validateIsbn(Long isbnNum) throws BookException;
	public void validatePrice(Double price) throws BookException;
	public void validateDescript(String descript) throws BookException;
}
