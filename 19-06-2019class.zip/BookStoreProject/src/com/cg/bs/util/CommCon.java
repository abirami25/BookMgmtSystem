package com.cg.bs.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CommCon 
{
	static Connection c;
	public  static Connection getCon() throws ClassNotFoundException {
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			 c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
					"system","system");
			System.out.println("Connected...");
		}
		catch(SQLException e)
		{
			System.out.println(e);
		}
		return c;
		
	}
}
