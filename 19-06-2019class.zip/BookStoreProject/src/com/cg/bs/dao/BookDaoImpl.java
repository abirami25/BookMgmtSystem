package com.cg.bs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.Scanner;


import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;
import com.cg.bs.util.CommCon;

public class BookDaoImpl implements IBookDao
{
    PreparedStatement pst;
    Connection cn;
    ResultSet rs;
    Scanner sc = new Scanner(System.in);
    BookBean bookBean = new BookBean();
	@Override
	public boolean validateUser(BookBean bookBean) 
	{
		
		String pass = "";
		try {
			cn=CommCon.getCon();
			Statement stmt = cn.createStatement();
			String user = bookBean.getUser();
			String upass=bookBean.getPassword();
			pst=cn.prepareStatement(QueryMapper.VALIDATE_USER_QUERY);
			pst.setString(1, user);
			rs=pst.executeQuery();
			//int count=0;
		    while(rs.next())
		    {
		    	//count++;
		    	
		    	pass = rs.getString(1);
		    	
		    }
		    if(pass.equals(upass))
		    	return true;
		    else
		    	return false;
		
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				rs.close();
				pst.close();
				cn.close();
			} 
			catch (SQLException e) 
			{
				
				System.out.println("Error in closing db connection");

			}
		}
		return false;
		
	}
	public static java.sql.Timestamp convert(java.util.Date now1)
	{
		return new java.sql.Timestamp(now1.getTime());
	}
	@Override
	public void listBook()
	{
		Date now = new Date();
			try
			{
				cn=CommCon.getCon();
				Statement stmt = cn.createStatement();
				pst=cn.prepareStatement(QueryMapper.LIST_BOOK_QUERY);
				//pst=cn.prepareStatement("select to_char( from book");
				rs=pst.executeQuery();
				while(rs.next())
			    {
					java.sql.Timestamp timestamp = convert(rs.getTimestamp(7));
					//if (timestamp != null)
					//now = new java.util.Date(timestamp.getTime());
					//System.out.println(timestamp);
					
			    	 System.out.println("Index: "+rs.getString(1)+" Id: "+rs.getString(2)+
			    			 " Title: "+rs.getString(4)+" Category: "+rs.getString(3)+
			    			 " Author: "+rs.getString(5)+" Price: "+rs.getDouble(8)+
			    			 " Last Updated: "+timestamp);
			    }
			}
			catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
	}
	@Override
	public void createBook(BookBean bookBean) 
	{// TODO Auto-generated method stub
		int queryResult=0;
		String id="";
		try
		{
			cn=CommCon.getCon();
			Statement stmt = cn.createStatement();
			String publish = bookBean.getLast_update();
			//System.out.println(publish);
			pst=cn.prepareStatement(QueryMapper.INSERT_BOOK_QUERY);
			pst.setString(1,bookBean.getCategory());
			pst.setString(2,bookBean.getTitle());
			pst.setString(3,bookBean.getAuthor());
			pst.setLong(4,bookBean.getIsbn());
			pst.setString(5,publish);
			pst.setDouble(6,bookBean.getPrice());
			pst.setString(7,bookBean.getDescript());
			queryResult=pst.executeUpdate();
			pst = cn.prepareStatement(QueryMapper.BOOKID_QUERY_SEQUENCE);
			rs=pst.executeQuery();
			if(rs.next())
			{
				id=rs.getString(1);
				System.out.println("Book inserted successfully with id "+id);
			}
			if(queryResult==0)
			{
				
				System.out.println("Inserting donor details failed ");

			}			
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		//return id;
		
	}
	@Override
	public boolean deleteBook(String id1) throws BookException{
		// TODO Auto-generated method stub
		try
		{
			cn=CommCon.getCon();
			Statement stmt = cn.createStatement();
			pst=cn.prepareStatement(QueryMapper.DELETE_BOOK_QUERY);
			pst.setString(1,id1);
			System.out.println("Are you sure you want to delete the book with id "+id1+" (yes/no)");
			String choice = sc.nextLine();
			
			if(choice.equals("yes"))
			{
				//ystem.out.println("Are you sure you want to delete the book with id "+id1+" (yes/no)");
				//String choice = sc.next();
				int count = pst.executeUpdate();
				if(count==1)
				{
				//int count = pst.executeUpdate();
				return true;
				
				}
				else
				{
					throw new BookException("Invalid Id");
					
				}
			}
			
		}
		catch (Exception e) {
			// TODO: handle exception
			throw new BookException("Tehnical problem occured refer log");
		}
		return false;
		
	}
	@Override
	public void editBook(String id2,BookBean bookBean)
	{
		// TODO Auto-generated method stub
		//Date now = null;
		try
		{
			cn=CommCon.getCon();
			Statement stmt = cn.createStatement();
			
			String publish = bookBean.getLast_update();
		
			pst=cn.prepareStatement(QueryMapper.UPDATE_BOOK_QUERY);
			pst.setString(1,bookBean.getCategory());
			pst.setString(2,bookBean.getTitle());
			pst.setString(3,bookBean.getAuthor());
			pst.setLong(4,bookBean.getIsbn());
			pst.setString(5,publish);
			pst.setDouble(6,bookBean.getPrice());
			pst.setString(7,bookBean.getDescript());
			pst.setString(8,id2);
			pst.executeQuery();
			System.out.println("Book with id "+id2+" updated successfully!");
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
