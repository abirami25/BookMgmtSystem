package com.cg.bs.dao;

public interface QueryMapper 
{
	public static final String VALIDATE_USER_QUERY="SELECT pwd FROM admin WHERE email=?";
	public static final String LIST_BOOK_QUERY="SELECT* from BOOK";
	public static final String DELETE_BOOK_QUERY="DELETE FROM book WHERE id_seq = ?";
	public static final String INSERT_BOOK_QUERY="INSERT INTO book VALUES(index_seq.NEXTVAL,id_seq.NEXTVAL,?,?,?,?,TO_DATE(?,'yyyy-mm-dd hh24:mi:ss'),?,?)";
	public static final String BOOKID_QUERY_SEQUENCE="SELECT id_seq.CURRVAL FROM DUAL";
	public static final String UPDATE_BOOK_QUERY="UPDATE book SET category=?,title=?,author=?,isbn=?,last_update=to_date(?,'yyyy-mm-dd hh24:mi:ss'),price=?,descript=? WHERE id_seq = ?";
}
