package com.cg.bs.service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.dao.BookDaoImpl;
import com.cg.bs.dao.IBookDao;
import com.cg.bs.exception.BookException;

public class BookServiceImpl implements IBookService
{
	Logger logger=Logger.getRootLogger();
	public BookServiceImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	IBookDao bookDao;
	
	/*******************************************************************************************************
	 - Function Name	:	validateAdmin(AdminBean adminBean)
	 - Input Parameters	:	AdminBean adminBean
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating admin and calls dao method validateAdmin(adminBean)
	 ********************************************************************************************************/
	
	public boolean validateAdmin(AdminBean adminBean) throws BookException
	{
		
		bookDao = new BookDaoImpl();
		return bookDao.validateAdmin(adminBean);
	}
	
	/*******************************************************************************************************
	 - Function Name	:	List<BookBean> listBook()
	 - Input Parameters	:	NA
	 - Return Type		:	List<BookBean>
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Listing book details fetching from the database and calls dao method listBook()
	 ********************************************************************************************************/
	
	@Override
	public List<BookBean> listBook() throws BookException
	{
		
		bookDao = new BookDaoImpl();
		return bookDao.listBook();
	}
	
	/*******************************************************************************************************
	 - Function Name	:	createBook(BookBean bookBean)
	 - Input Parameters	:	BookBean bookBean
	 - Return Type		:	int
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Inserting book details into the database and calls dao method createBook(bookBean)
	 ********************************************************************************************************/
	
	@Override
	public int createBook(BookBean bookBean) throws BookException {
		bookDao = new BookDaoImpl();
		return bookDao.createBook(bookBean);
	}
	
	/*******************************************************************************************************
	 - Function Name	:	deleteBook(String bookId1)
	 - Input Parameters	:	String bookId1
	 - Return Type		:	int
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Deleting book details from the database and calls dao method deleteBook(bookId1)
	 ********************************************************************************************************/
	
	@Override
	public int deleteBook(String bookId1) throws BookException 
	{
		bookDao = new BookDaoImpl();
		return bookDao.deleteBook(bookId1);
		//return false;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	editBook(String bookId2,BookBean bookBean)
	 - Input Parameters	:	String bookId2,BookBean bookBean
	 - Return Type		:	int
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Editing book details in the database and calls dao method editBook(bookId2,bookBean)
	 ********************************************************************************************************/
	
	@Override
	public int editBook(String bookId2,BookBean bookBean) throws BookException {
		bookDao = new BookDaoImpl();
		return bookDao.editBook(bookId2,bookBean);
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateId(String id1)
	 - Input Parameters	:	String id1
	 - Return Type		:	boolean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the book id in the database and calls dao method validateId(id1)
	 ********************************************************************************************************/
	
	@Override
	public boolean validateId(String bookId) throws BookException 
	{
		bookDao = new BookDaoImpl();
		return bookDao.validateId(bookId);
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateDateFormat(String publishDate)
	 - Input Parameters	:	String publishDate
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the publish date
	 * @throws ParseException 
	 ********************************************************************************************************/
	
	@Override
	public void validateDateFormat(String publishDate) throws BookException{
		LocalDate localDate = LocalDate.now();
		Date currentDate = java.sql.Date.valueOf(localDate);
		String nameRegEx ="^\\d\\d\\d\\d-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01]) (00|[0-9]|1[0-9]|2[0-3]):([0-9]|[0-5][0-9]):([0-9]|[0-5][0-9])$";
		if (!Pattern.matches(nameRegEx, publishDate)) {
			throw new BookException("No strings allowed here and enter the publish date with correct format mentioned\n");
		}
		else
		{
			try
			{
			SimpleDateFormat formatter=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
			Date givenDate = formatter.parse(publishDate);
			if(givenDate.compareTo(currentDate)>0)
			{
				throw new BookException("Date should be lesser");
			}
			}
			catch(ParseException e)
			{
				throw new BookException("Parsing error");
			}
			
		}
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateIsbn(Long isbnNum)
	 - Input Parameters	:	Long isbnNum
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the ISBN number
	 ********************************************************************************************************/
	
	@Override
	public void validateIsbn(Long isbnNum) throws BookException {//9780596520687
		String isbnRegEx = "^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][0-9]{10}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)(?:97[89][- ]?)?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$";
		if (!Pattern.matches(isbnRegEx, isbnNum.toString())) {
			throw new BookException("ISBN number should be 10 or 13 digits with correct format...\n");
		}
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validatePrice(Double price)
	 - Input Parameters	:	Double price
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the book price
	 ********************************************************************************************************/
	@Override
	public void validatePrice(Double price) throws BookException {
		if (price < 100 || price > 50000) {
			throw new BookException("Price should not be less than 100 and should not exceed 50000... \n");
		}
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateDescript(String descript)
	 - Input Parameters	:	String descript
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the book description
	 ********************************************************************************************************/
	@Override
	public void validateDescript(String descript) throws BookException {
		if (descript.length()<5 || descript.length()>300) {
			throw new BookException("Description shoud be greater than 5 characters and should not exceed 300 characters... \n");
	}
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateAuthor(String authorName)
	 - Input Parameters	:	String authorName
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the book author
	 ********************************************************************************************************/
	
	@Override
	public void validateAuthor(String authorName) throws BookException {
		String authorRegEx = "[A-Z]{1}[a-zA-Z .]{2,29}";
		if (!Pattern.matches(authorRegEx, authorName)) {
			throw new BookException("Author name should contain only characters with first letter capitalised and length must be between 3 and 30 characters\n");
		}
		
		
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateTitle(String titleName)
	 - Input Parameters	:	String titleName
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the book title
	 ********************************************************************************************************/
	public void validateTitle(String titleName) throws BookException {
		char firstLetter = titleName.charAt(0);
		int titleLength = titleName.length();
		if (Character.isLetter(firstLetter)&&Character.isLowerCase(firstLetter)) {
			throw new BookException("Author name should contain first letter capitalised\n");
		}
		else if(titleLength<3 || titleLength>30)
		{
			throw new BookException("Length of title name must be between 3 and 30\n");
		}
	}
	
	/*******************************************************************************************************
	 - Function Name	:	validateCategory(String categoryName)
	 - Input Parameters	:	String categoryName
	 - Return Type		:	void
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	Validating the book category
	 ********************************************************************************************************/
	@Override
	public void validateCategory(String categoryName) throws BookException {
		// TODO Auto-generated method stub
		String categoryRegEx = "[A-Z]{1}[a-zA-Z ]{2,29}";
		int categoryLength = categoryName.length();
		//String nameRegEx = "^[a-zA-Z0-9 ]+$";
		if (!Pattern.matches(categoryRegEx, categoryName)) {
			throw new BookException("Category name should contain only characters with first letter capitalised\n");
		}
		else if(categoryLength<3 || categoryLength>30)
		{
			throw new BookException("Length of category name must be between 3 and 30\n");
		}
	}
	
}