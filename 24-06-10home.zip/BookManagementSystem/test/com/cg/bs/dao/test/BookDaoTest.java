package com.cg.bs.dao.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bs.bean.BookBean;
import com.cg.bs.dao.BookDaoImpl;
import com.cg.bs.exception.BookException;

public class BookDaoTest {

	BookDaoImpl daoImpl = null;

	@Before
	public void setUp() throws Exception {
		daoImpl = new BookDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}

	/****************************************************************************
	 * @throws BookException
	 * Test case for createBook(book) method
	 ****************************************************************************/
	@Test
	public void testAddProduct() throws BookException {

		BookBean book = new BookBean("Rich and Pretty","Rumaan Alam","Humour",1000,"2009-9-9 9:9:9",9780810993136L,"Comedy Story");

		int bookId = daoImpl.createBook(book);
		assertNotNull(bookId);
	}

	/****************************************************************************
	 * @throws BookException
	 * Test case for listBook() method
	 ****************************************************************************/
	@Test
	public void testListBook() throws BookException{


		List<BookBean> list = daoImpl.listBook();
			assertTrue(list.size() > 0);
		
	}
	
	/****************************************************************************
	 * @throws BookException
	 * Test case for editBook(bookId, bookBean) method
	 ****************************************************************************/
	@Test
	public void testEditBook() throws BookException
	{
		BookBean bookBean = new BookBean();
		bookBean.setCategory("Horror");
		bookBean.setTitle("Open");
		bookBean.setAuthor("James");
		bookBean.setIsbn(9876543210L);
		bookBean.setLastUpdate("2008-8-8 10:12:12");
		bookBean.setPrice(2000);
		bookBean.setDescript("The Best thriller story");
		
		int editCount = daoImpl.editBook("44", bookBean);
		assertTrue(editCount == 1);
	}
	
	/****************************************************************************
	 * @throws BookException
	 * Test case for deleteBook(bookId) method
	 ****************************************************************************/
	
	@Test
	public void testDeleteBook() throws BookException
	{
		int deleteCount = daoImpl.deleteBook("66");
		assertTrue(deleteCount == 1);
	}
	

}
