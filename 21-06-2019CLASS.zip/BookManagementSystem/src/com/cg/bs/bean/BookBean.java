package com.cg.bs.bean;


public class BookBean 
{
	
	private String id;
	private String index;
	private String title;
	private String author;
	private String category;
	private double price;
	private String last_update;
	private long isbn;
	private String descript;
	
	
	
	public BookBean(String title, String author, String category, double price,
			String last_update, long isbn, String descript) {
		super();
		this.title = title;
		this.author = author;
		this.category = category;
		this.price = price;
		this.last_update = last_update;
		this.isbn = isbn;
		this.descript = descript;
	}
	public long getIsbn() {
		return isbn;
	}
	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}
	public String getDescript() {
		return descript;
	}
	public void setDescript(String descript) {
		this.descript = descript;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(String index) {
		this.index = index;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getLast_update() {
		return last_update;
	}
	public void setLast_update(String last_update) {
		this.last_update = last_update;
	}
}
