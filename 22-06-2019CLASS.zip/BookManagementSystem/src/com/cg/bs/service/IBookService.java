package com.cg.bs.service;

import java.util.List;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;

public interface IBookService 
{
	public boolean validateAdmin(AdminBean adminBean) throws BookException; 
	public List<BookBean> listBook() throws BookException;
	public int createBook(BookBean bookBean) throws BookException;
	public int deleteBook(String bookId1) throws BookException;
	public int editBook(String bookId2,BookBean bookBean) throws BookException;
	public void validateName(String categoryName) throws BookException;
	public void validateDate(String publishDate) throws BookException;
	public void validateIsbn(Long isbnNum) throws BookException;
	public void validatePrice(Double price) throws BookException;
	public void validateDescript(String descript) throws BookException;
	public boolean validateId(String id1) throws BookException;
	
	
}
