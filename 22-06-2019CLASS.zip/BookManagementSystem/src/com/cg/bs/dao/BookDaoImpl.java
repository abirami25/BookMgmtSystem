package com.cg.bs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;
import com.cg.bs.util.DBConnection;

public class BookDaoImpl implements IBookDao {

	Logger logger = Logger.getRootLogger();

	public BookDaoImpl() {
		PropertyConfigurator.configure("resources//log4j.properties");

	}

	PreparedStatement preparedStatement;
	Connection connection;
	ResultSet resultSet;
	Scanner scanner = new Scanner(System.in);

	// BookBean bookBean = new BookBean();
	// AdminBean adminBean = new AdminBean();
	@Override
	public boolean validateAdmin(AdminBean adminBean) throws BookException {

		String passwordFromDB = "";
		try {
			connection = DBConnection.getConnection();

			String admin = adminBean.getAdmin();
			String adminPassword = adminBean.getAdminPassword();
			preparedStatement = connection.prepareStatement(QueryMapper.VALIDATE_USER_QUERY);
			preparedStatement.setString(1, admin);
			resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {
				passwordFromDB = resultSet.getString(1);
			}
			if (passwordFromDB.equals(adminPassword))
				return true;
			else
				return false;

		} catch (SQLException e) {
			// TODO: handle exception
			logger.error("Unable to create prepared statement object");
			throw new BookException("Unable to create prepared statement object");
		} finally {
			try {
				resultSet.close();
				preparedStatement.close();
				connection.close();
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new BookException("Error in closing db connection");

			}
		}

	}

	public static java.sql.Timestamp convert(java.util.Date dateFromDb) {
		return new java.sql.Timestamp(dateFromDb.getTime());
	}

	@Override
	public List<BookBean> listBook() throws BookException {

		List<BookBean> beanList = new ArrayList<>();

		connection = DBConnection.getConnection();
		try {
			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement(QueryMapper.LIST_BOOK_QUERY);

			resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				BookBean bookBean = new BookBean();
				Timestamp timeStamp = convert(resultSet.getTimestamp(7));
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-mm-dd HH:mm:ss");
				String dateToPrint = dateFormat.format(timeStamp);
				bookBean.setBookId(resultSet.getString(1));
				bookBean.setBookIndex(resultSet.getString(2));
				bookBean.setTitle(resultSet.getString(4));
				bookBean.setCategory(resultSet.getString(3));
				bookBean.setAuthor(resultSet.getString(5));
				bookBean.setPrice(resultSet.getDouble(8));
				bookBean.setLastUpdate(dateToPrint);
				beanList.add(bookBean);
			}
		} catch (SQLException e) {
			// TODO: handle exception
			logger.error("Unable to create prepared statement object");
			throw new BookException("Unable to create Prepared Statement object");
		}
		return beanList;
	}

	@Override
	public int createBook(BookBean bookBean) throws BookException {// TODO Auto-generated method stub
		int queryResult = 0;
		String bookId = "";
		try {
			connection = DBConnection.getConnection();

			// String publish = bookBean.getLastUpdate();
			// System.out.println(publish);
			preparedStatement = connection.prepareStatement(QueryMapper.INSERT_BOOK_QUERY);
			preparedStatement.setString(1, bookBean.getCategory());
			preparedStatement.setString(2, bookBean.getTitle());
			preparedStatement.setString(3, bookBean.getAuthor());
			preparedStatement.setLong(4, bookBean.getIsbn());
			preparedStatement.setString(5, bookBean.getLastUpdate());
			preparedStatement.setDouble(6, bookBean.getPrice());
			preparedStatement.setString(7, bookBean.getDescript());
			queryResult = preparedStatement.executeUpdate();
			preparedStatement = connection.prepareStatement(QueryMapper.BOOKID_QUERY_SEQUENCE);
			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				bookId = resultSet.getString(1);
				logger.info("Donor details added successfully:");
				// System.out.println("Book inserted successfully with id " + id);
			}
			if (queryResult == 0) {
				logger.error("Insertion failed ");
				throw new BookException("Inserting donor details failed ");

			}
		} catch (SQLException e) {

			logger.error("Unable to create Prepared Statement object");
			throw new BookException("Unable to create Prepared Statement object");
		}

		return Integer.parseInt(bookId);

	}

	@Override
	public int deleteBook(String bookId1) throws BookException {
		int rowsDeleted = 0;
		try {
			connection = DBConnection.getConnection();

			preparedStatement = connection.prepareStatement(QueryMapper.DELETE_BOOK_QUERY);
			preparedStatement.setString(1, bookId1);
			rowsDeleted = preparedStatement.executeUpdate();
		} catch (SQLException e) {
			logger.error("Unable to create prepared statement object");
			throw new BookException("Unable to create prepared statement object");
		}
		return rowsDeleted;

	}

	@Override
	public int editBook(String bookId2, BookBean bookBean) throws BookException {
		// TODO Auto-generated method stub
		// Date now = null;
		int editCount = 0;
		try 
		{
			connection = DBConnection.getConnection();
			preparedStatement = connection.prepareStatement(QueryMapper.UPDATE_BOOK_QUERY);
			preparedStatement.setString(1, bookBean.getCategory());
			preparedStatement.setString(2, bookBean.getTitle());
			preparedStatement.setString(3, bookBean.getAuthor());
			preparedStatement.setLong(4, bookBean.getIsbn());
			preparedStatement.setString(5, bookBean.getLastUpdate());
			preparedStatement.setDouble(6, bookBean.getPrice());
			preparedStatement.setString(7, bookBean.getDescript());
			preparedStatement.setString(8, bookId2);
			editCount = preparedStatement.executeUpdate();
		} 
		catch (SQLException e)
		{
			// TODO: handle exception
			logger.error("Unable to create prepared statement object");
			throw new BookException("Unable to create prepared statement object");
		}
		return editCount;
	}

	public boolean validateId(String id) throws BookException {

		// Date now = null;
		try {
			connection = DBConnection.getConnection();

			// String publish = bookBean.getLast_update();

			preparedStatement = connection.prepareStatement(QueryMapper.SELECT_ID);
			preparedStatement.setString(1, id);
			// System.out.println(id);
			int count = preparedStatement.executeUpdate();
			// System.out.println(count);
			if (count == 1)
				return true;
			else {
				logger.info("Record Not found");
				throw new BookException("Invalid Id");
			}

		} catch (SQLException e) {

			e.printStackTrace();
			logger.error(e.getMessage());
			throw new BookException("Tehnical problem occured refer log");
		}
	}

}
