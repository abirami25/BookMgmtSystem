package com.cg.bs.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;
import com.cg.bs.service.BookServiceImpl;
import com.cg.bs.service.IBookService;

public class BookMain // 9781408855690
{
	static IBookService bookService = new BookServiceImpl();
	static Scanner scanner = new Scanner(System.in);
	static AdminBean adminBean = new AdminBean();
	static BookBean bookBean = new BookBean(null, null, null, 0.0d, null, 0L, null);
	static Logger logger = Logger.getRootLogger();

	static int bookId, deleteCount = 0, editCount = 0;
	static String getBookId1, getBookId2;
	static String categoryName = "";
	static String titleName = "";
	static String authorName = "";
	static Long isbnNum;
	static String publishDate;
	static Double price;
	static String descript;

	public static void main(String[] args) throws BookException {
		PropertyConfigurator.configure("resources//log4j.properties");
		System.out.println("----BOOK STORE----");
		System.out.println("\n----BOOK MANAGEMENT SYSTEM----\n");

		while (true)
		{
			bookService = new BookServiceImpl();
			System.out.println("Enter E-mail:");
			adminBean.setAdmin(scanner.nextLine());
			System.out.println("Enter Password:");
			adminBean.setAdminPassword(scanner.nextLine());
			try
			{
			if (bookService.validateAdmin(adminBean)) {
				System.out.println("Welcome " + adminBean.getAdmin() + "!\n");
				break;
			} 
			else 
			{
				System.err.println("Enter username and password correctly!");
			}
			}
			catch(BookException e)
			{
				logger.error(e.getMessage());
				System.err.println(e.getMessage());
			}
		} // end of admin while

		/*Menu*/
		while (true) {
			System.out.println("----MENU----");
			System.out.println("1.List Book ");
			System.out.println("2.Create Book");
			System.out.println("3.Edit Book");
			System.out.println("4.Delete Book");
			System.out.println("5.Exit");

			boolean flag = false;
			do {

				System.out.println("Select an option:");
				try {

					int option = scanner.nextInt();
					flag = true;
					switch (option) {
					/*Book Listing Page*/
					case 1:
						System.out.println("----Book Listing Page----");
						// bookService = new BookServiceImpl();
						try {
							List<BookBean> printList = bookService.listBook();
							System.out.println(String.format("%-10s %-10s %-20s %-20s %-20s %-20s %s", "Index", "Id",
									"Title", "Category", "Author", "Price", "Last Updated"));

							for (BookBean printBean : printList) {
								System.out.println(String.format("%-10s %-10s %-20s %-20s %-20s %-20s %s",
										printBean.getBookId(), printBean.getBookIndex(), printBean.getTitle(),
										printBean.getCategory(), printBean.getAuthor(), printBean.getPrice(),
										printBean.getLastUpdate()));
							}
						} 
						catch (BookException e)
						{
							logger.error(e.getMessage());
							System.err.println(e.getMessage());
						}
						break;
						/*Create Book*/
					case 2:
						scanner.nextLine();
						System.out.println("----Create Book----");
						try {
							bookBean = populateBookBean();
							/* Separate section code is below */
							bookId = bookService.createBook(bookBean);
							System.out.println("Book created successfully with book ID " + bookId);
						} 
						catch (BookException e) 
						{
							logger.error(e.getMessage());
							System.out.println(e.getMessage());
						}

						break;
						/*Edit Book*/
					case 3:
						System.out.println("----Edit Book----");
						bookService = new BookServiceImpl();
						while (true) 
						{
							System.out.println("Enter the book id want to edit:");
							// sc.next();
							getBookId2 = scanner.next();
							scanner.nextLine();
							try {
								if(Integer.parseInt(getBookId2)>0)
								{
								if (bookService.validateId(getBookId2)) {
									bookBean = populateBookBean();
								}
								editCount = bookService.editBook(getBookId2, bookBean);

								if (editCount != 0) {
									logger.info("Record edited Successfully");
									System.out.println("Book with id " + getBookId2 + " edited successfully!");
									break;
								} else {
									logger.error("Editing book details failed");
									throw new BookException("Editing book details failed");
								}
								//break;
							} 
							}
							catch(NumberFormatException e)
							{
								System.err.println("Book Id should be a number");
							}
							catch (BookException e) {
								logger.error(e.getMessage());
								System.err.println(e.getMessage());
							}
						}
						break;
						/*Delete Book*/
					case 4:
						System.out.println("----Delete Book----");
						bookService = new BookServiceImpl();
						while (true) {
							System.out.println("Enter the book id want to delete:");
							scanner.nextLine();
							getBookId1 = scanner.next();
							try {
								if(Integer.parseInt(getBookId1)>0)
								{
								if (bookService.validateId(getBookId1)) {
									System.out.println("Are you sure you want to delete the book with id " + getBookId1
											+ " (yes/no)");
									while (true) {
										String choice = scanner.nextLine();

										if (choice.equalsIgnoreCase("yes")) {
											// preparedStatement.executeQuery();
											deleteCount = bookService.deleteBook(getBookId1);
											if (deleteCount != 0) {
												logger.info("Record deleted Successfully");
												System.out.println(
														"Book with id " + getBookId1 + " deleted successfully!");
												break;
											} else {
												logger.error("Deletion failed ");
												throw new BookException("Deleting book details failed ");
											}
											//break;
										} else if (choice.equalsIgnoreCase("no")) {
											logger.info("Record Not deleted");
											break;
										} else {
											logger.info("Entry without yes/no");
											System.err.println("Enter yes/no");
											
										}
									}
									
									break;
								}
							}
							}
							catch (BookException e) {
								logger.error(e.getMessage());
								System.err.println(e.getMessage());
							}
							catch(NumberFormatException e)
							{
								System.err.println("Book Id should be a number");
							}
						}
						break;
					case 5:
						System.out.println("----Exited----");
						System.exit(0);
						break;

					default:
						flag = false;
						System.err.println("Input should be 1 to 5");
						break;

					}// end of switch
				} catch (InputMismatchException e) {
					scanner.nextLine();
					flag = false;
					logger.error("Enter digits only");
					System.err.println("Enter digits only");
				}
			} while (!flag);
		} // end of menu while
	}// end of main

	private static BookBean populateBookBean() {
		// BookBean bookBean = new BookBean();
		boolean categoryNameFlag = false;
		do {
			// sc.nextLine();
			System.out.println("Enter category");
			// categoryName = sc.nextLine();
			try {
				categoryName = scanner.nextLine();
				bookService.validateName(categoryName);
				bookBean.setCategory(categoryName);
				categoryNameFlag = true;
				break;
			} catch (BookException e) {
				categoryNameFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			}
		} while (!categoryNameFlag);

		// String titleName = "";
		boolean titleNameFlag = false;
		do {
			System.out.println("Enter title");
			try {
				titleName = scanner.nextLine();
				bookService.validateName(titleName);
				bookBean.setTitle(titleName);
				titleNameFlag = true;
				break;
			} catch (BookException e) {
				titleNameFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			}
		} while (!titleNameFlag);

		// String authorName = "";
		boolean authorNameFlag = false;
		do {
			System.out.println("Enter author");
			try {
				authorName = scanner.nextLine();
				bookService.validateName(authorName);
				bookBean.setAuthor(authorName);
				authorNameFlag = true;
				break;
			} catch (BookException e) {
				authorNameFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			}
		} while (!authorNameFlag);

		// Long isbnNum;
		boolean isbnNumFlag = false;
		do {
			System.out.println("Enter isbn");
			try {
				isbnNum = scanner.nextLong();
				scanner.nextLine();
				bookService.validateIsbn(isbnNum);
				bookBean.setIsbn(isbnNum);
				isbnNumFlag = true;
				break;
			} catch (BookException e) {
				isbnNumFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			} catch (InputMismatchException e) {
				isbnNumFlag = false;
				scanner.nextLine();
				logger.error("exception occured", e);
				System.err.println("Please enter a number");
			}
		} while (!isbnNumFlag);

		// String publishDate = "";
		boolean publishDateFlag = false;
		do {
			// System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
			try {
				System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
				// sc.nextLine();
				publishDate = scanner.nextLine();
				// System.out.println(publishDate);
				bookService.validateDateFormat(publishDate);
				bookBean.setLastUpdate(publishDate);
		      	publishDateFlag = true;
				break;
			} catch (BookException e) {
				publishDateFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			}
		} while (!publishDateFlag);

		// Double price;
		boolean priceFlag = false;
		do {
			System.out.println("Enter price");
			try {
				price = scanner.nextDouble();
				System.out.println(price);
				bookService.validatePrice(price);
				bookBean.setPrice(price);
				priceFlag = true;
				break;
			} catch (BookException e) {
				priceFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			} catch (InputMismatchException e) {
				priceFlag = false;
				scanner.nextLine();
				logger.error("exception occured", e);
				System.err.println("Please enter a number");
			}
		} while (!priceFlag);

		// String descript;
		boolean descriptFlag = false;
		do {
			System.out.println("Enter description");
			try {
				scanner.nextLine();
				descript = scanner.nextLine();
				bookService.validateDescript(descript);
				bookBean.setDescript(descript);
				descriptFlag = true;
				break;
			} catch (BookException e) {
				descriptFlag = false;
				logger.error("exception occured", e);
				System.err.println(e.getMessage());
			}
		} while (!descriptFlag);

		return bookBean;
	}
}

/*
 * //String categoryName = ""; boolean categoryNameFlag = false; do {
 * //sc.nextLine(); System.out.println("Enter category"); //categoryName =
 * sc.nextLine(); try { categoryName = sc.nextLine();
 * bookService.validateName(categoryName); bookBean.setCategory(categoryName);
 * categoryNameFlag = true; break; } catch(BookException e) { categoryNameFlag =
 * false; System.err.println(e.getMessage()); } }while(!categoryNameFlag);
 * 
 * //String titleName = ""; boolean titleNameFlag = false; do {
 * System.out.println("Enter title"); try { titleName = sc.nextLine();
 * bookService.validateName(titleName); bookBean.setTitle(titleName);
 * titleNameFlag = true; break; } catch(BookException e) { titleNameFlag =
 * false; System.err.println(e.getMessage()); } }while(!titleNameFlag);
 * 
 * //String authorName = ""; boolean authorNameFlag = false; do {
 * System.out.println("Enter author"); try { authorName = sc.nextLine();
 * bookService.validateName(authorName); bookBean.setAuthor(authorName);
 * authorNameFlag = true; break; } catch(BookException e) { authorNameFlag =
 * false; System.err.println(e.getMessage()); } }while(!authorNameFlag);
 * 
 * //Long isbnNum; boolean isbnNumFlag = false; do {
 * System.out.println("Enter isbn"); try { isbnNum = sc.nextLong();
 * bookService.validateIsbn(isbnNum); bookBean.setIsbn(isbnNum); isbnNumFlag =
 * true; break; } catch(BookException e) { isbnNumFlag = false;
 * System.err.println(e.getMessage()); } }while(!isbnNumFlag);
 * 
 * //String publishDate = ""; boolean publishDateFlag = false; do {
 * System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)"); try {
 * sc.nextLine(); publishDate = sc.nextLine();
 * bookService.validateDate(publishDate); bookBean.setLast_update(publishDate);
 * publishDateFlag = true; break; } catch(BookException e) { publishDateFlag =
 * false; System.err.println(e.getMessage()); } }while(!publishDateFlag);
 * 
 * //Double price; boolean priceFlag = false; do {
 * System.out.println("Enter price"); try { price = sc.nextDouble();
 * //System.out.println(price); bookService.validatePrice(price);
 * bookBean.setPrice(price); priceFlag = true; break; } catch(BookException e) {
 * priceFlag = false; System.err.println(e.getMessage()); } }while(!priceFlag);
 * 
 * //String descript; boolean descriptFlag = false; do {
 * System.out.println("Enter description"); try { sc.nextLine(); descript =
 * sc.nextLine(); bookService.validateDescript(descript);
 * bookBean.setDescript(descript); descriptFlag = true; break; }
 * catch(BookException e) { descriptFlag = false;
 * System.err.println(e.getMessage()); } }while(!descriptFlag);
 * 
 */
