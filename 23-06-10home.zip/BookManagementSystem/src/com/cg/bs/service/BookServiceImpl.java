package com.cg.bs.service;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.dao.BookDaoImpl;
import com.cg.bs.dao.IBookDao;
import com.cg.bs.exception.BookException;

public class BookServiceImpl implements IBookService
{
	Logger logger=Logger.getRootLogger();
	public BookServiceImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	IBookDao bookDao;
	public boolean validateAdmin(AdminBean adminBean) throws BookException
	{
		
		bookDao = new BookDaoImpl();
		return bookDao.validateAdmin(adminBean);
	}
	@Override
	public List<BookBean> listBook() throws BookException
	{
		
		bookDao = new BookDaoImpl();
		return bookDao.listBook();
	}
	@Override
	public int createBook(BookBean bookBean) throws BookException {
		bookDao = new BookDaoImpl();
		return bookDao.createBook(bookBean);
	}
	@Override
	public int deleteBook(String bookId1) throws BookException 
	{
		bookDao = new BookDaoImpl();
		return bookDao.deleteBook(bookId1);
		//return false;
	}
	@Override
	public int editBook(String bookId2,BookBean bookBean) throws BookException {
		bookDao = new BookDaoImpl();
		return bookDao.editBook(bookId2,bookBean);
	}
	
	@Override
	public boolean validateId(String id1) throws BookException 
	{
		bookDao = new BookDaoImpl();
		return bookDao.validateId(id1);
	}
	
	
	public void validateName(String categoryName) throws BookException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{2,29}";
		if (!Pattern.matches(nameRegEx, categoryName)) {
			throw new BookException("first letter should be capital and length must be in between 3 to 30... \n");
		}
	}
	
	
	
	@Override
	public void validateDateFormat(String publishDate) throws BookException {
		LocalDate localDate = LocalDate.now();
		Date currentDate = java.sql.Date.valueOf(localDate);
		System.out.println("Current Date: "+currentDate);
		try {
		SimpleDateFormat formatter=new SimpleDateFormat("yyyy-mm-dd hh:mm:ss");
		Date givenDate = formatter.parse(publishDate);
		System.out.println("Date Format: "+givenDate);
		if(givenDate.compareTo(currentDate)>0)
		{
			logger.info("Date should be lesser than the current date");
			throw new BookException("Date should be lesser than the current date");
		}
		}

		catch(ParseException e)
		{
			logger.info("Parsing error");;
			throw new BookException("Parsing error: Publish date should be in the format [yyyy-mm-dd hh:mm:ss]");
		}
		
	}
	@Override
	public void validateIsbn(Long isbnNum) throws BookException {
		String isbnRegEx = "^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][0-9]{10}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)(?:97[89][- ]?)?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$";
		if (!Pattern.matches(isbnRegEx, isbnNum.toString())) {
			logger.info("Wrong ISBN format");
			throw new BookException("ISBN number should be 10 or 13 digits with correct format...\n");
		}
	}
	@Override
	public void validatePrice(Double price) throws BookException {
		if (price < 100 || price > 50000) {
			logger.info("Price is invalid");
			throw new BookException("Price should not be less than 100 and should not exceed 50000... \n");
		}
	}
	@Override
	public void validateDescript(String descript) throws BookException {
		if (descript.length()<5) {
			logger.info("Description length too long");
			throw new BookException("Description shoud be greater than 5 characters and should not exceed 300 characters... \n");
	}
	}
	
}
	
	


