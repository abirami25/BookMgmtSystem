package com.cg.bs.dao.test;

//import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bs.dao.BookDaoImpl;
import com.cg.bs.exception.BookException;
import com.cg.bs.util.DBConnection;



public class DBConnectionTest {
	static BookDaoImpl daoTest;
	static Connection dbCon;

	@BeforeClass
	public static void initialise() {
		daoTest = new BookDaoImpl();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	/**
	 * Test case for Establishing Connection
	 * 
	 * @throws DonorException
	 **/
	@Test
	public void test() throws BookException {
		Connection dbCon = DBConnection.getConnection();
		Assert.assertNotNull(dbCon);
	}

	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daoTest = null;
		dbCon = null;
	}

}
