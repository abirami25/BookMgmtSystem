package com.cg.bs.dao.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.bs.bean.BookBean;
import com.cg.bs.dao.BookDaoImpl;
import com.cg.bs.exception.BookException;

public class BookDaoTest {

	BookDaoImpl daoImpl = null;

	@Before
	public void setUp() throws Exception {
		daoImpl = new BookDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}

	@Test
	public void testAddProduct() throws BookException {

		BookBean book = new BookBean("Diary of a Kid","Jeff","Humour",1000,"2009-9-9 9:9:9",9780810993136L,"Comedy Story");

		int genId = daoImpl.createBook(book);
		assertNotNull(genId);
	}

	@Test
	public void testListBook() throws BookException{


		List<BookBean> list = daoImpl.listBook();
			assertTrue(list.size() > 0);
		
	}
	
	@Test
	public void testEditBook() throws BookException
	{
		BookBean bookBean = new BookBean();
		bookBean.setCategory("Horror");
		bookBean.setTitle("House of Leaves");
		bookBean.setAuthor("James");
		bookBean.setIsbn(9876543210L);
		bookBean.setLastUpdate("2008-8-8 10:12:12");
		bookBean.setPrice(2000);
		bookBean.setDescript("The Best thriller story");
		
		int editCount = daoImpl.editBook("1", bookBean);
		assertTrue(editCount == 1);
	}
	
	@Test
	public void testDeleteBook() throws BookException
	{
		int deleteCount = daoImpl.deleteBook("1");
		assertTrue(deleteCount == 1);
	}
	

}
