package com.cg.bs.bean;


public class BookBean 
{
	
	
	private String bookId;
	private String bookIndex;
	private String title;
	private String author;
	private String category;
	private double price;
	private String lastUpdate;
	private long isbn;
	private String descript;
	
	public BookBean()
	{
		
	}
	
	public BookBean(String title, String author, String category, double price, String lastUpdate)
	{
		super();
		this.title = title;
		this.author = author;
		this.category = category;
		this.price = price;
		this.lastUpdate = lastUpdate;
		}
	
	public BookBean(String title, String author, String category, double price, String lastUpdate, long isbn,
			String descript) {
		super();
		this.title = title;
		this.author = author;
		this.category = category;
		this.price = price;
		this.lastUpdate = lastUpdate;
		this.isbn = isbn;
		this.descript = descript;
	}
	
	public long getIsbn() {
		return isbn;
	}
	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}
	
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookIndex() {
		return bookIndex;
	}
	public void setBookIndex(String bookIndex) {
		this.bookIndex = bookIndex;
	}
	public String getLastUpdate() {
		return lastUpdate;
	}
	public void setLastUpdate(String lastUpdate) {
		this.lastUpdate = lastUpdate;
	}
	
	public String getDescript() {
		return descript;
	}
	public void setDescript(String descript) {
		this.descript = descript;
	}
	

	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "BookBean [bookId=" + bookId + ", bookIndex=" + bookIndex + ", title=" + title + ", author=" + author
				+ ", category=" + category + ", price=" + price + ", lastUpdate=" + lastUpdate + "]";
	}
}
