package com.cg.bs.ui;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;
import com.cg.bs.service.BookServiceImpl;
import com.cg.bs.service.IBookService;

public class BookMain // 9781408855690
{
	static IBookService bookService = new BookServiceImpl();
	static Scanner scanner = new Scanner(System.in);
	static AdminBean adminBean = new AdminBean();
	static BookBean bookBean = new BookBean(null, null, null, 0.0d, null, 0L, null);
	static Logger logger = Logger.getRootLogger();

	static int bookId, deleteCount = 0, editCount = 0;
	static String getBookId1, getBookId2;
	static String categoryName = "";
	static String titleName = "";
	static String authorName = "";
	static Long isbnNum;
	static String publishDate;
	static Double price;
	static String descript;

	public static void main(String[] args) throws BookException {
		PropertyConfigurator.configure("resources//log4j.properties");
		System.out.println("----BOOK STORE----");
		System.out.println("\n----BOOK MANAGEMENT SYSTEM----\n");

		while (true)
		{
			bookService = new BookServiceImpl();
			System.out.println("Enter E-mail:");
			adminBean.setAdmin(scanner.nextLine());
			System.out.println("Enter Password:");
			adminBean.setAdminPassword(scanner.nextLine());
			try
			{
			if (bookService.validateAdmin(adminBean)) {
				System.out.println("Welcome " + adminBean.getAdmin() + "!\n");
				break;
			} 
			else 
			{
				System.err.println("Enter username and password correctly!");
			}
			}
			catch(BookException e)
			{
				logger.error(e.getMessage());
				System.err.println(e.getMessage());
			}
		} // end of admin while

		/*Menu*/
		while (true) {
			System.out.println("----MENU----");
			System.out.println("1.List Book ");
			System.out.println("2.Create Book");
			System.out.println("3.Edit Book");
			System.out.println("4.Delete Book");
			System.out.println("5.Exit");

			boolean flag = false;
			do {

				System.out.println("Select an option:");
				try {

					int option = scanner.nextInt();
					flag = true;
					switch (option) {
					/*Book Listing Page*/
					case 1:
						System.out.println("----Book Listing Page----");
						try {
							List<BookBean> printList = bookService.listBook();
							System.out.println(String.format("%-10s %-10s %-20s %-20s %-20s %-20s %s", "Index", "Id",
									"Title", "Category", "Author", "Price", "Last Updated"));

							for (BookBean printBean : printList) {
								System.out.println(String.format("%-10s %-10s %-20s %-20s %-20s %-20s %s",
										printBean.getBookId(), printBean.getBookIndex(), printBean.getTitle(),
										printBean.getCategory(), printBean.getAuthor(), printBean.getPrice(),
										printBean.getLastUpdate()));
							}
						} 
						catch (BookException bookException)
						{
							logger.error(bookException.getMessage());
							System.err.println(bookException.getMessage());
						}
						break;
						/*Create Book*/
					case 2:
						scanner.nextLine();
						System.out.println("----Create New Book Page----");
						try {
							bookBean = populateBookBean();
							bookId = bookService.createBook(bookBean);
							System.out.println("Book created successfully with book ID " + bookId);
						} 
						catch (BookException bookException) 
						{
							logger.error(bookException.getMessage());
							System.err.println(bookException.getMessage());
						}

						break;
						/*Edit Book*/
					case 3:
						System.out.println("----Edit Book Page----");
						bookService = new BookServiceImpl();
						while (true) 
						{
							System.out.println("Enter the book id want to edit:");
							getBookId2 = scanner.next();
							scanner.nextLine();
							try {
								if(Integer.parseInt(getBookId2)>0)
								{
								if (bookService.validateId(getBookId2)) {
									bookBean = populateBookBean();
								}
								editCount = bookService.editBook(getBookId2, bookBean);

								if (editCount != 0) {
									logger.info("Record edited Successfully");
									System.out.println("Book with id " + getBookId2 + " edited successfully!");
									break;
								} else {
									logger.error("Editing book details failed");
									throw new BookException("Editing book details failed");
								}
								
							} 
							}
							catch(NumberFormatException numberFormatException)
							{
								System.err.println("Book Id should be a number");
							}
							catch (BookException bookException) {
								logger.error(bookException.getMessage());
								System.err.println(bookException.getMessage());
							}
						}
						break;
						/*Delete Book*/
					case 4:
						System.out.println("----Delete Book Confirmation Dialog----");
						bookService = new BookServiceImpl();
						while (true) {
							System.out.println("Enter the book id want to delete:");
							scanner.nextLine();
							getBookId1 = scanner.next();
							try {
								if(Integer.parseInt(getBookId1)>0)
								{
								if (bookService.validateId(getBookId1)) {
									System.out.println("Are you sure you want to delete the book with id " + getBookId1
											+ " (yes/no)");
									while (true) {
										String choice = scanner.nextLine();

										if (choice.equalsIgnoreCase("yes")) {
											// preparedStatement.executeQuery();
											deleteCount = bookService.deleteBook(getBookId1);
											if (deleteCount != 0) {
												logger.info("Record deleted Successfully");
												System.out.println(
														"Book with id " + getBookId1 + " deleted successfully!");
												break;
											} else {
												logger.error("Deletion failed ");
												throw new BookException("Deleting book details failed ");
											}
											//break;
										} else if (choice.equalsIgnoreCase("no")) {
											logger.info("Record Not deleted");
											break;
										} else {
											logger.info("Entry without yes/no");
											System.err.println("Enter yes/no");
											
										}
									}
									
									break;
								}
							}
							}
							catch (BookException bookException) {
								logger.error(bookException.getMessage());
								System.err.println(bookException.getMessage());
							}
							catch(NumberFormatException numberFormatException)
							{
								System.err.println("Book Id should be a number");
							}
						}
						break;
					case 5:
						System.out.println("----Exited----");
						System.exit(0);
						break;

					default:
						flag = false;
						System.err.println("Input should be 1 to 5");
						break;

					}// end of switch
				} catch (InputMismatchException inputMismatchException) {
					scanner.nextLine();
					flag = false;
					logger.error(inputMismatchException);
					System.err.println("Enter digits only");
				}
			} while (!flag);
		} // end of menu while
	}// end of main

	/*******************************************************************************************************
	 - Function Name	:	populateBookBean()
	 - Input Parameters	:	NA
	 - Return Type		:	BookBean
	 - Throws			:  	BookException
	 - Author			:	CAPGEMINI
	 - Creation Date	:	24/06/2019
	 - Description		:	This function will be called by main and will return a validated bean
	 						object OR null if details are invalid
	 ********************************************************************************************************/
		private static BookBean populateBookBean() {
		boolean categoryNameFlag = false;
		do {
			System.out.println("Enter category");
			try {
				categoryName = scanner.nextLine();
				bookService.validateCategory(categoryName);
				bookBean.setCategory(categoryName);
				categoryNameFlag = true;
				break;
			} catch (BookException bookException) {
				categoryNameFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			}
		} while (!categoryNameFlag);

		boolean titleNameFlag = false;
		do {
			System.out.println("Enter title");
			try {
				titleName = scanner.nextLine();
				bookService.validateTitle(titleName);
				bookBean.setTitle(titleName);
				titleNameFlag = true;
				break;
			} catch (BookException bookException) {
				titleNameFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			}
		} while (!titleNameFlag);

		boolean authorNameFlag = false;
		do {
			System.out.println("Enter author");
			try {
				authorName = scanner.nextLine();
				bookService.validateAuthor(authorName);
				
				bookBean.setAuthor(authorName);
				authorNameFlag = true;
				break;
			} catch (BookException bookException) {
				authorNameFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			}
			catch(NumberFormatException numberFormatException)
			{
				authorNameFlag = false;
				logger.error("exception occured", numberFormatException);
				System.err.println("Author Name should not contain numbers");
			}
		} while (!authorNameFlag);

		boolean isbnNumFlag = false;
		do {
			System.out.println("Enter isbn");
			try {
				isbnNum = scanner.nextLong();
				scanner.nextLine();
				bookService.validateIsbn(isbnNum);
				bookBean.setIsbn(isbnNum);
				isbnNumFlag = true;
				break;
			} catch (BookException bookException) {
				isbnNumFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			} catch (InputMismatchException inputMismatchException) {
				isbnNumFlag = false;
				scanner.nextLine();
				logger.error("exception occured", inputMismatchException);
				System.err.println("Please enter a number");
			}
		} while (!isbnNumFlag);

		boolean publishDateFlag = false;
		do {
			try {
				System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
				publishDate = scanner.nextLine();
				bookService.validateDateFormat(publishDate);
				bookBean.setLastUpdate(publishDate);
		      	publishDateFlag = true;
				break;
			} catch (BookException bookException) {
				publishDateFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			}
		} while (!publishDateFlag);

		boolean priceFlag = false;
		do {
			System.out.println("Enter price");
			try {
				price = scanner.nextDouble();
				bookService.validatePrice(price);
				bookBean.setPrice(price);
				priceFlag = true;
				break;
			} catch (BookException bookException) {
				priceFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			} catch (InputMismatchException inputMisMatchException) {
				priceFlag = false;
				scanner.nextLine();
				logger.error("exception occured", inputMisMatchException);
				System.err.println("Please enter a number");
			}
		} while (!priceFlag);

		boolean descriptFlag = false;
		do {
			System.out.println("Enter description");
			try {
				scanner.nextLine();
				descript = scanner.nextLine();
				bookService.validateDescript(descript);
				bookBean.setDescript(descript);
				descriptFlag = true;
				break;
			} catch (BookException bookException) {
				descriptFlag = false;
				logger.error("exception occured", bookException);
				System.err.println(bookException.getMessage());
			}
		} while (!descriptFlag);

		return bookBean;
	}
}

