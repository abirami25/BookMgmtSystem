package com.cg.bs.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;
import com.cg.bs.service.BookServiceImpl;
import com.cg.bs.service.IBookService;

public class BookMain //9781408855690
{
	static IBookService bookService = new BookServiceImpl();
	static Scanner sc = new Scanner(System.in);
	static AdminBean adminBean = new AdminBean();
	static BookBean bookBean = new BookBean(null,null,null,0.0d,null,0L,null);
	static Logger logger = Logger.getRootLogger();
	
	String id;
	static String categoryName = "";
	static String titleName = "";
	static String authorName = "";
	static Long isbnNum;
	static String publishDate = "";
	static Double price;
	static String descript;
	
	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("resources//log4j.properties");
		//BookBean bookBean = null;
		System.out.println("****BOOK STORE****");
		System.out.println("****BOOK MANAGEMENT SYSTEM****");
						while(true)
						{
						//bookBean = new BookBean();
						bookService = new BookServiceImpl();
						
						System.out.println("Enter E-mail:");
						adminBean.setUser(sc.nextLine());
						System.out.println("Enter Password:");
						adminBean.setPassword(sc.nextLine());
						if(bookService.validateUser(adminBean))
						{
							System.out.println("Welcome "+adminBean.getUser()+"\n");
							break;
						}
						else
						{
							System.out.println("Enter username and password correctly!");
						}
						}
						// show menu
						
						while(true)
						{
						System.out.println("****MENU****");
						System.out.println("1.List Book ");
						System.out.println("2.Create Book");
						System.out.println("3.Edit Book");
						System.out.println("4.Delete Book");
						System.out.println("5.Exit");
						System.out.println("Select an option:");
						int option = sc.nextInt();
						if(option>5)
							System.out.println("Enter a valid option [1-5]");
						else
						{
						switch(option)
						{
						case 1:
							System.out.println("****Book Listing Page****");
							bookService = new BookServiceImpl();
							bookService.listBook();
							break;
						case 2:
							sc.nextLine();
							System.out.println("****Create Book****");
							bookBean = populateBookBean();
							/*Separate section code is below*/
							int idValue = bookService.createBook(bookBean);
							//bookBean = null;
							break;
						case 3:
							System.out.println("****Edit Book****");
							bookService = new BookServiceImpl();
							while(true)
							{
							System.out.println("Enter the id want to edit:");
							//sc.next();
							String id2 = sc.next();
							sc.nextLine();
							try {
								if(bookService.validateId(id2))
								{
									bookBean = populateBookBean();
								}
								bookService.editBook(id2,bookBean);
								break;
								}
							 catch (BookException e) {
								// TODO Auto-generated catch block
								 logger.error("exception occured", e);
								System.err.println("ERROR : "+ e.getMessage());
							}
							}
							break;	
							/*
							System.out.println("Enter category");
							bookBean.setCategory(sc.nextLine());
							System.out.println("Enter title");
							bookBean.setTitle(sc.nextLine());
							System.out.println("Enter author");
							bookBean.setAuthor(sc.nextLine());
							System.out.println("Enter isbn");
							bookBean.setIsbn(sc.nextLong());
							System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
							sc.nextLine();
							bookBean.setLast_update(sc.nextLine());
							//String publish = bookBean.getLast_update();
							System.out.println("Enter price");
							bookBean.setPrice(sc.nextDouble());
							System.out.println("Enter description");
							sc.next();
							bookBean.setDescript(sc.nextLine());*/
							
							//bookService.editBook(id2,bookBean);
							//break;
						case 4:
							System.out.println("****Delete Book****");
							bookService = new BookServiceImpl();
							//sc.next();
							while(true)
							{
							System.out.println("Enter the id want to delete:");
							sc.nextLine();
							String id1 = sc.next();
							try {
								if(bookService.validateId(id1))
								{
									bookService.deleteBook(id1);
									//System.out.println("Book with id "+id1+" deleted successfully!");
									break;
									}
								}
								//} 
								catch (BookException e) {
								// TODO Auto-generated catch block
									logger.error("exception occured", e);
								System.err.println(e.getMessage());
							}
							}
							break;
							//sc.next();
							/*System.out.println("Are you sure you want to delete the book with id "+id1+" (yes/no)");
							String choice = sc.next();
							if(choice.equals("yes"))
							{
								bookService.deleteBook(id1);
							}
							else
							{
								return;
							}*/
							
						case 5:
							System.out.println("****Exited****");
							System.exit(0);
							break;
						}
						}
						}
}
	private static BookBean populateBookBean()
	{
		//BookBean bookBean = new BookBean();
		//String categoryName = "";
		boolean categoryNameFlag = false;
		do
		{
		//sc.nextLine();
		System.out.println("Enter category");
		//categoryName = sc.nextLine();
		try
		{
		categoryName = sc.nextLine();
		bookService.validateName(categoryName);
		bookBean.setCategory(categoryName);
		categoryNameFlag = true;
		break;
		}
		catch(BookException e)
		{
			categoryNameFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		}while(!categoryNameFlag);
		
		//String titleName = "";
		boolean titleNameFlag = false;
		do
		{
		System.out.println("Enter title");
		try
		{
		titleName = sc.nextLine();
		bookService.validateName(titleName);
		bookBean.setTitle(titleName);
		titleNameFlag = true;
		break;
		}
		catch(BookException e)
		{
			titleNameFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		}while(!titleNameFlag);
		
		//String authorName = "";
		boolean authorNameFlag = false;
		do
		{
		System.out.println("Enter author");
		try
		{
		authorName = sc.nextLine();
		bookService.validateName(authorName);
		bookBean.setAuthor(authorName);
		authorNameFlag = true;
		break;
		}
		catch(BookException e)
		{
			authorNameFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		}while(!authorNameFlag);
		
		//Long isbnNum;
		boolean isbnNumFlag = false;
		do
		{
		System.out.println("Enter isbn");
		try
		{
		isbnNum = sc.nextLong();
		sc.nextLine();
		bookService.validateIsbn(isbnNum);
		bookBean.setIsbn(isbnNum);
		isbnNumFlag = true;
		break;
		}
		catch(BookException e)
		{
			isbnNumFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		catch(InputMismatchException e)
		{
			isbnNumFlag = false;
			sc.nextLine();
			logger.error("exception occured", e);
			System.err.println("Please enter a number");
		}
		}while(!isbnNumFlag);
		
		//String publishDate = "";
		boolean publishDateFlag = false;
		do
		{
		//System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
		try
			{
			System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
			//sc.nextLine();
			publishDate = sc.nextLine();
			//System.out.println(publishDate);
			bookService.validateDate(publishDate);
			bookBean.setLast_update(publishDate);
			publishDateFlag = true;
			break;
			}
		catch(BookException e)
		{
			publishDateFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		}while(!publishDateFlag);
		
		//Double price;
		boolean priceFlag = false;
		do
		{
		System.out.println("Enter price");
		try
		{
		price = sc.nextDouble();
		//System.out.println(price);
		bookService.validatePrice(price);
		bookBean.setPrice(price);
		priceFlag = true;
		break;
		}
		catch(BookException e)
		{
			priceFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		}while(!priceFlag);
		
		//String descript;
		boolean descriptFlag = false;
		do
		{
		System.out.println("Enter description");
		try
		{
		sc.nextLine();
		descript = sc.nextLine();
		bookService.validateDescript(descript);
		bookBean.setDescript(descript);
		descriptFlag = true;
		break;
		}
		catch(BookException e)
		{
			descriptFlag = false;
			logger.error("exception occured", e);
			System.err.println(e.getMessage());
		}
		}while(!descriptFlag);
		
		return bookBean;
	}
}

/*		//String categoryName = "";
boolean categoryNameFlag = false;
do
{
//sc.nextLine();
System.out.println("Enter category");
//categoryName = sc.nextLine();
try
{
categoryName = sc.nextLine();
bookService.validateName(categoryName);
bookBean.setCategory(categoryName);
categoryNameFlag = true;
break;
}
catch(BookException e)
{
	categoryNameFlag = false;
	System.err.println(e.getMessage());
}
}while(!categoryNameFlag);

//String titleName = "";
boolean titleNameFlag = false;
do
{
System.out.println("Enter title");
try
{
titleName = sc.nextLine();
bookService.validateName(titleName);
bookBean.setTitle(titleName);
titleNameFlag = true;
break;
}
catch(BookException e)
{
	titleNameFlag = false;
	System.err.println(e.getMessage());
}
}while(!titleNameFlag);

//String authorName = "";
boolean authorNameFlag = false;
do
{
System.out.println("Enter author");
try
{
authorName = sc.nextLine();
bookService.validateName(authorName);
bookBean.setAuthor(authorName);
authorNameFlag = true;
break;
}
catch(BookException e)
{
	authorNameFlag = false;
	System.err.println(e.getMessage());
}
}while(!authorNameFlag);

//Long isbnNum;
boolean isbnNumFlag = false;
do
{
System.out.println("Enter isbn");
try
{
isbnNum = sc.nextLong();
bookService.validateIsbn(isbnNum);
bookBean.setIsbn(isbnNum);
isbnNumFlag = true;
break;
}
catch(BookException e)
{
	isbnNumFlag = false;
	System.err.println(e.getMessage());
}
}while(!isbnNumFlag);

//String publishDate = "";
boolean publishDateFlag = false;
do
{
System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
try
	{
	sc.nextLine();
	publishDate = sc.nextLine();
	bookService.validateDate(publishDate);
	bookBean.setLast_update(publishDate);
	publishDateFlag = true;
	break;
	}
catch(BookException e)
{
	publishDateFlag = false;
	System.err.println(e.getMessage());
}
}while(!publishDateFlag);

//Double price;
boolean priceFlag = false;
do
{
System.out.println("Enter price");
try
{
price = sc.nextDouble();
//System.out.println(price);
bookService.validatePrice(price);
bookBean.setPrice(price);
priceFlag = true;
break;
}
catch(BookException e)
{
	priceFlag = false;
	System.err.println(e.getMessage());
}
}while(!priceFlag);

//String descript;
boolean descriptFlag = false;
do
{
System.out.println("Enter description");
try
{
sc.nextLine();
descript = sc.nextLine();
bookService.validateDescript(descript);
bookBean.setDescript(descript);
descriptFlag = true;
break;
}
catch(BookException e)
{
	descriptFlag = false;
	System.err.println(e.getMessage());
}
}while(!descriptFlag);

*/
