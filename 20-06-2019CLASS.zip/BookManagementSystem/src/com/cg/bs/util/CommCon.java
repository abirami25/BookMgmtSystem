package com.cg.bs.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;
import com.cg.bs.exception.BookException;

import oracle.jdbc.pool.OracleDataSource;

public class CommCon 
{
	private static Connection conn = null;
	private static CommCon instance = null;
	private static Properties props = null;
	private static OracleDataSource dataSource = null;


	private CommCon() throws BookException {
		try {
			props = loadProperties();
			dataSource = prepareDataSource();
		} catch (IOException e) {
			throw new BookException(
					" Could not read the database details from properties file ");
		} catch (SQLException e) {
			throw new BookException(e.getMessage());
		}

	}


	public static CommCon getInstance() throws BookException {
		synchronized (CommCon.class) {
			if (instance == null) {
				instance = new CommCon();
			}
		}
		return instance;
	}

	public Connection getCon() throws BookException {
		try {

			conn = dataSource.getConnection();

		} catch (SQLException e) {
			
			throw new BookException(" Database connection problem");
		}
		return conn;
	}

	
	private Properties loadProperties() throws IOException {

		if (props == null) {
			Properties newProps = new Properties();
			String fileName = "resources/jdbc.properties";

			InputStream inputStream = new FileInputStream(fileName);
			newProps.load(inputStream);

			inputStream.close();

			return newProps;
		} else {
			return props;
		}
	}

	
	private OracleDataSource prepareDataSource() throws SQLException {

		if (dataSource == null) {
			if (props != null) {
				String connectionURL = props.getProperty("dburl");
				String username = props.getProperty("username");
				String password = props.getProperty("password");

				dataSource = new OracleDataSource();

				dataSource.setURL(connectionURL);
				dataSource.setUser(username);
				dataSource.setPassword(password);
			}
		}
		return dataSource;
	}
}


/*static Connection c;
public  static Connection getCon() throws ClassNotFoundException {
	try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		 c=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe",
				"system","system");
		System.out.println("Connected...");
	}
	catch(SQLException e)
	{
		System.out.println(e);
	}
	return c;
	
}*/