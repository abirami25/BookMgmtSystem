package com.cg.bs.service;
import com.cg.bs.dao.IBookDao;
import com.cg.bs.exception.BookException;
import com.cg.bs.dao.BookDaoImpl;

import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;

public class BookServiceImpl implements IBookService
{
	Logger logger=Logger.getRootLogger();
	public BookServiceImpl()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	
	IBookDao bookDao;
	public boolean validateUser(AdminBean adminBean)
	{
		
		bookDao = new BookDaoImpl();
		return bookDao.validateUser(adminBean);
	}
	@Override
	public void listBook()
	{
		
		bookDao = new BookDaoImpl();
		bookDao.listBook();
	}
	@Override
	public int createBook(BookBean bookBean) {
		// TODO Auto-generated method stub
		String id;
		bookDao = new BookDaoImpl();
		return bookDao.createBook(bookBean);
		//return id;
	}
	@Override
	public void deleteBook(String id1) throws BookException 
	{
		// TODO Auto-generated method stub
		bookDao = new BookDaoImpl();
		bookDao.deleteBook(id1);
		//return false;
	}
	@Override
	public void editBook(String id2,BookBean bookBean) {
		// TODO Auto-generated method stub
		bookDao = new BookDaoImpl();
		bookDao.editBook(id2,bookBean);
	}
	
	@Override
	public boolean validateId(String id1) throws BookException 
	{
		// TODO Auto-generated method stub
		bookDao = new BookDaoImpl();
		return bookDao.validateId(id1);
	}
	
	
	public void validateName(String categoryName) throws BookException {
		String nameRegEx = "[A-Z]{1}[a-zA-Z ]{2,29}";
		if (!Pattern.matches(nameRegEx, categoryName)) {
			throw new BookException("first letter should be capital and length must be in between 3 to 30... \n");
		}
	}
	@Override
	public void validateDate(String publishDate) throws BookException {
		// TODO Auto-generated method stub
		String nameRegEx ="^\\d\\d\\d\\d-(0?[1-9]|1[0-2])-(0?[1-9]|[12][0-9]|3[01]) (00|[0-9]|1[0-9]|2[0-3]):([0-9]|[0-5][0-9]):([0-9]|[0-5][0-9])$";
		if (!Pattern.matches(nameRegEx, publishDate)) {
			logger.info("Wrong Publish date format");
			throw new BookException("Enter the publish date correctly...\n");
		}
		
	}
	@Override
	public void validateIsbn(Long isbnNum) throws BookException {
		// TODO Auto-generated method stub
		String nameRegEx = "^(?:ISBN(?:-1[03])?:? )?(?=[0-9X]{10}$|(?=(?:[0-9]+[- ]){3})[- 0-9X]{13}$|97[89][0-9]{10}$|(?=(?:[0-9]+[- ]){4})[- 0-9]{17}$)(?:97[89][- ]?)?[0-9]{1,5}[- ]?[0-9]+[- ]?[0-9]+[- ]?[0-9X]$";
		if (!Pattern.matches(nameRegEx, isbnNum.toString())) {
			logger.info("Wrong ISBN format");
			throw new BookException("ISBN number should be 10 or 13 digits with correct format...\n");
		}
	}
	@Override
	public void validatePrice(Double price) throws BookException {
		// TODO Auto-generated method stub
		if (price < 100 || price > 50000) {
			logger.info("Price is invalid");
			throw new BookException("Price should not be less than 100 and should not exceed 50000... \n");
		}
	}
	@Override
	public void validateDescript(String descript) throws BookException {
		// TODO Auto-generated method stub
		//String nameRegEx = "[a-zA-Z0-9 ]{4,49}";
		if (descript.length()<5) {
			logger.info("Description length too long");
			throw new BookException("Description shoud be greater than 5 characters and should not exceed 300 characters... \n");
	}
	}
	
}
	
	


