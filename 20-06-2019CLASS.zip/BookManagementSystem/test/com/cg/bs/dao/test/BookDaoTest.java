package com.cg.bs.dao.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import com.cg.bs.bean.BookBean;
import com.cg.bs.dao.BookDaoImpl;
import com.cg.bs.exception.BookException;

public class BookDaoTest {

	BookDaoImpl daoImpl = null;

	@Before
	public void setUp() throws Exception {
		daoImpl = new BookDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		daoImpl = null;
	}

	@Test
	public void testAddProduct() throws BookException {

		BookBean book = new BookBean("Diary of a Kid","Jeff","Humour",1000,"2009-9-9 9:9:9",9780810993136L,"Comedy Story");

		int genId = daoImpl.createBook(book);
		assertNotNull(genId);
	}

	

}
