package com.cg.bs.dao;

import java.util.List;

import com.cg.bs.bean.AdminBean;
import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;

public interface IBookDao 
{
	public boolean validateAdmin(AdminBean adminBean) throws BookException;
	public List<BookBean> listBook() throws BookException;
	public int createBook(BookBean bookBean) throws BookException;
	public int deleteBook(String bookId1) throws BookException;
	public int editBook(String bookId2,BookBean bookBean) throws BookException;
	public boolean validateId(String bookId) throws BookException;
}
