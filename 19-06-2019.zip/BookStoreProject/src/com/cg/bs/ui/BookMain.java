package com.cg.bs.ui;

import java.util.Scanner;


import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;
import com.cg.bs.service.BookServiceImpl;
import com.cg.bs.service.IBookService;

public class BookMain 
{
	static IBookService bookService = null;
	static Scanner sc = new Scanner(System.in);
	//static BookBean bookBean = new BookBean();
	String id;
	static String categoryName = "";
	static String titleName = "";
	static String authorName = "";
	static Long isbnNum;
	static String publishDate = "";
	static Double price;
	static String descript;
	
	public static void main(String[] args) 
	{
		 BookBean bookBean = null;
		
		while(true)
		{
		bookBean = new BookBean();
		bookService = new BookServiceImpl();
		System.out.println("****BOOK STORE****");
		System.out.println("Enter E-mail:");
		bookBean.setUser(sc.nextLine());
		System.out.println("Enter Password:");
		bookBean.setPassword(sc.nextLine());
		if(bookService.validateUser(bookBean))
		{
			System.out.println("Welcome "+bookBean.getUser()+"\n");
			break;
		}
		else
			System.out.println("Enter username and password correctly!");
		}
						// show menu
						
					while(true)
						{
					System.out.println("****MENU****");
					System.out.println("1.List Book ");
					System.out.println("2.Create Book");
					System.out.println("3.Edit Book");
					System.out.println("4.Delete Book");
					System.out.println("5.Exit");
					System.out.println("Select an option:");
					int option = sc.nextInt();
					if(option>5)
						System.out.println("Enter a valid option [1-5]");
					else
					{
						switch(option)
						{
						case 1:
							System.out.println("****Book Listing Page****");
							bookService = new BookServiceImpl();
							bookService.listBook();
							//sc.nextLine();
							break;
						case 2:
							sc.nextLine();
							System.out.println("****Create Book****");
							while(bookBean==null)
							bookBean = populateBookBean();
							/*Separate section code is below*/
					
							bookService.createBook(bookBean);
							break;
						case 3:
							System.out.println("****Edit Book****");
							bookService = new BookServiceImpl();
							while(true)
							{
							System.out.println("Enter the id want to edit:");
							//sc.next();
							String id2 = sc.next();
							sc.nextLine();
							try {
								if(bookService.validateId(id2))
								{
									bookBean = populateBookBean();
								}
								bookService.editBook(id2,bookBean);
								break;
								}
							 catch (BookException e) {
								// TODO Auto-generated catch block
								System.err.println("ERROR : "+ e.getMessage());
							}
							}
							break;	
							/*
							System.out.println("Enter category");
							bookBean.setCategory(sc.nextLine());
							System.out.println("Enter title");
							bookBean.setTitle(sc.nextLine());
							System.out.println("Enter author");
							bookBean.setAuthor(sc.nextLine());
							System.out.println("Enter isbn");
							bookBean.setIsbn(sc.nextLong());
							System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
							sc.nextLine();
							bookBean.setLast_update(sc.nextLine());
							//String publish = bookBean.getLast_update();
							System.out.println("Enter price");
							bookBean.setPrice(sc.nextDouble());
							System.out.println("Enter description");
							sc.next();
							bookBean.setDescript(sc.nextLine());*/
							
							
						case 4:
							System.out.println("****Delete Book****");
							bookService = new BookServiceImpl();
							//sc.next();
							while(true)
							{
							System.out.println("Enter the id want to delete:");
							sc.nextLine();
							String id1 = sc.next();
							try {
								if(bookService.validateId(id1))
								{
									bookService.deleteBook(id1);
									//System.out.println("Book with id "+id1+" deleted successfully!");
									break;
									}
								}
								//} 
								catch (BookException e) {
								// TODO Auto-generated catch block
								System.err.println(e.getMessage());
							}
							}
							break;
							//sc.next();
							/*System.out.println("Are you sure you want to delete the book with id "+id1+" (yes/no)");
							String choice = sc.next();
							if(choice.equals("yes"))
							{
								bookService.deleteBook(id1);
							}
							else
							{
								return;
							}*/
							
						case 5:
							System.out.println("****Exited****");
							System.exit(0);
							break;
						}
						}
						}
}
	public static BookBean populateBookBean()
	{
		BookBean bookBean = new BookBean();
		//String categoryName = "";
		boolean categoryNameFlag = false;
		do
		{
		//sc.nextLine();
		System.out.println("Enter category");
		//categoryName = sc.nextLine();
		try
		{
			//sc.nextLine();
		categoryName = sc.nextLine();
		bookService.validateName(categoryName);
		bookBean.setCategory(categoryName);
		categoryNameFlag = true;
		break;
		}
		catch(BookException e)
		{
			categoryNameFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!categoryNameFlag);
		
		//String titleName = "";
		boolean titleNameFlag = false;
		do
		{
		System.out.println("Enter title");
		try
		{
		titleName = sc.nextLine();
		bookService.validateName(titleName);
		bookBean.setTitle(titleName);
		titleNameFlag = true;
		break;
		}
		catch(BookException e)
		{
			titleNameFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!titleNameFlag);
		
		//String authorName = "";
		boolean authorNameFlag = false;
		do
		{
		System.out.println("Enter author");
		try
		{
		authorName = sc.nextLine();
		bookService.validateName(authorName);
		bookBean.setAuthor(authorName);
		authorNameFlag = true;
		break;
		}
		catch(BookException e)
		{
			authorNameFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!authorNameFlag);
		
		//Long isbnNum;
		boolean isbnNumFlag = false;
		do
		{
		System.out.println("Enter isbn");//9781408855690
		try
		{
		isbnNum = sc.nextLong();
		bookService.validateIsbn(isbnNum);
		bookBean.setIsbn(isbnNum);
		isbnNumFlag = true;
		break;
		}
		catch(BookException e)
		{
			isbnNumFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!isbnNumFlag);
		
		//String publishDate = "";
		boolean publishDateFlag = false;
		do
		{
		System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
		try
			{
			sc.nextLine();
			publishDate = sc.nextLine();
			bookService.validateDate(publishDate);
			bookBean.setLast_update(publishDate);
			publishDateFlag = true;
			break;
			}
		catch(BookException e)
		{
			publishDateFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!publishDateFlag);
		
		//Double price;
		boolean priceFlag = false;
		do
		{
		System.out.println("Enter price");
		try
		{
		price = sc.nextDouble();
		//System.out.println(price);
		bookService.validatePrice(price);
		bookBean.setPrice(price);
		priceFlag = true;
		break;
		}
		catch(BookException e)
		{
			priceFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!priceFlag);
		
		//String descript;
		boolean descriptFlag = false;
		do
		{
		System.out.println("Enter description");
		try
		{
		sc.nextLine();
		descript = sc.nextLine();
		//sc.nextLine();
		bookService.validateDescript(descript);
		bookBean.setDescript(descript);
		descriptFlag = true;
		break;
		}
		catch(BookException e)
		{
			descriptFlag = false;
			System.err.println(e.getMessage());
		}
		}while(!descriptFlag);
		
		return bookBean;
	}
}

/*		//String categoryName = "";
boolean categoryNameFlag = false;
do
{
//sc.nextLine();
System.out.println("Enter category");
//categoryName = sc.nextLine();
try
{
categoryName = sc.nextLine();
bookService.validateName(categoryName);
bookBean.setCategory(categoryName);
categoryNameFlag = true;
break;
}
catch(BookException e)
{
	categoryNameFlag = false;
	System.err.println(e.getMessage());
}
}while(!categoryNameFlag);

//String titleName = "";
boolean titleNameFlag = false;
do
{
System.out.println("Enter title");
try
{
titleName = sc.nextLine();
bookService.validateName(titleName);
bookBean.setTitle(titleName);
titleNameFlag = true;
break;
}
catch(BookException e)
{
	titleNameFlag = false;
	System.err.println(e.getMessage());
}
}while(!titleNameFlag);

//String authorName = "";
boolean authorNameFlag = false;
do
{
System.out.println("Enter author");
try
{
authorName = sc.nextLine();
bookService.validateName(authorName);
bookBean.setAuthor(authorName);
authorNameFlag = true;
break;
}
catch(BookException e)
{
	authorNameFlag = false;
	System.err.println(e.getMessage());
}
}while(!authorNameFlag);

//Long isbnNum;
boolean isbnNumFlag = false;
do
{
System.out.println("Enter isbn");
try
{
isbnNum = sc.nextLong();
bookService.validateIsbn(isbnNum);
bookBean.setIsbn(isbnNum);
isbnNumFlag = true;
break;
}
catch(BookException e)
{
	isbnNumFlag = false;
	System.err.println(e.getMessage());
}
}while(!isbnNumFlag);

//String publishDate = "";
boolean publishDateFlag = false;
do
{
System.out.println("Enter publish date(yyyy-mm-dd hh24:mi:ss)");
try
	{
	sc.nextLine();
	publishDate = sc.nextLine();
	bookService.validateDate(publishDate);
	bookBean.setLast_update(publishDate);
	publishDateFlag = true;
	break;
	}
catch(BookException e)
{
	publishDateFlag = false;
	System.err.println(e.getMessage());
}
}while(!publishDateFlag);

//Double price;
boolean priceFlag = false;
do
{
System.out.println("Enter price");
try
{
price = sc.nextDouble();
//System.out.println(price);
bookService.validatePrice(price);
bookBean.setPrice(price);
priceFlag = true;
break;
}
catch(BookException e)
{
	priceFlag = false;
	System.err.println(e.getMessage());
}
}while(!priceFlag);

//String descript;
boolean descriptFlag = false;
do
{
System.out.println("Enter description");
try
{
sc.nextLine();
descript = sc.nextLine();
bookService.validateDescript(descript);
bookBean.setDescript(descript);
descriptFlag = true;
break;
}
catch(BookException e)
{
	descriptFlag = false;
	System.err.println(e.getMessage());
}
}while(!descriptFlag);

*/
