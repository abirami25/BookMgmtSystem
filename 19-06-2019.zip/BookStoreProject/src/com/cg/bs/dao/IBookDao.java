package com.cg.bs.dao;

import com.cg.bs.bean.BookBean;
import com.cg.bs.exception.BookException;

public interface IBookDao 
{
	public boolean validateUser(BookBean bookBean);
	public void listBook();
	public void createBook(BookBean bookBean);
	public void deleteBook(String id1) throws BookException;
	public void editBook(String id2,BookBean bookBean);
	public boolean validateId(String id) throws BookException;
}
